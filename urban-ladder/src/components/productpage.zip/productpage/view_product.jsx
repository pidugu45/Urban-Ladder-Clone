import styled from "styled-components";
export const View_product = styled.button`
  border: none;
  width: auto;
  height: 30px;
  background-color: transparent;
  border-radius: 3px;
  margin-top: 3px;
  background-color: coral;
  color: white;
  padding: 2px 15px;
  display: none;
  margin-bottom: 5px;
`;

