import "./product.css";
export const Title_div = () => {
  return (
    <>
      <div>
        <h1 id="pidugutitle">Beds With Storage</h1>
        <p id="no_of_products">(20 Products)</p>
      </div>
    </>
  );
};
