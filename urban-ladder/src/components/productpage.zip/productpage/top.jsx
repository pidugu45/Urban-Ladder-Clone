import "./product.css"
export const Top_div = () => {
    return <>
        <div id="top_div">
        <a href="#">Furniture Home</a> <span>{">"}</span>
        <a href="#"> Bedroom Funiture</a> <span>{">"}</span>
        <a href="#">Beds</a><span>{">"}</span>
            <a href="#">Beds with Storage</a>
        </div>
    </>
}